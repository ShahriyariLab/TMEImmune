Files in this folder includes network propagated scores using immunotherapy target(s) as seed gene(s).
